import javax.servlet.*;
public class Emp {
	private int id;
	private String firstname,lastname,email;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {  
	    return firstname;  
	}  
	public void setFirstName(String firstname) {  
	    this.firstname = firstname;  
	}
	
	public String getLastName() {  
	    return lastname;  
	}  
	public void setLastName(String lastname) {  
	    this.lastname = lastname;  
	}
	
	
	public String getEmail() {  
	    return email;  
	}  
	public void setEmail(String email) {  
	    this.email = email;  
	}
}
